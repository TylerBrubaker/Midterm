package com.example.tyler_brubaker_guess_the_number_game;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    private TextView myText;
    private Button button1;

    //static final String

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        ImageView Image = findViewById(R.id.image);
        TextView myText = findViewById(R.id.guessTextView);

        int text = getIntent().getExtras().getInt("USER");
        int num = getIntent().getExtras().getInt("RAN");

        Log.d("Activity2", "The answer is " + num);

        if(text == num) {
            Image.setImageResource(R.drawable.smiley_face);
            String message = getApplicationContext().getString(R.string.Correct);
            myText.setText(message);
        } else{
            Image.setImageResource(R.drawable.sad_face);
            myText.setText("Your guess is not correct, " + num + " is the correct answer");
        }

        button1 = findViewById(R.id.backButton);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
