package com.example.tyler_brubaker_guess_the_number_game;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button mButton;
    private EditText mEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final int mRandom  = new Random().nextInt(6 - 1) + 1;
        final String temp = Integer.toString(mRandom);

        mEditText = findViewById(R.id.numberEdit);

        mButton = findViewById(R.id.button);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final int val = Integer.parseInt(mEditText.getText().toString());

                Log.d("MainActivity", String.valueOf(mEditText.getText()));

                Intent i = new Intent(MainActivity.this, Activity2.class);
                i.putExtra("USER", Integer.valueOf(val));
                i.putExtra("RAN", Integer.valueOf(mRandom));
                startActivity(i);
            }
        });
    }
}
